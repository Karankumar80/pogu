# Deri Kurniawan's 3D Portfolio

[![Deri-Kurniawan - 3D Portfolio](https://img.shields.io/static/v1?label=Deri-Kurniawan&message=3d-portfolio&color=blue&logo=github)](https://github.com/Deri-Kurniawan/3d-portfolio "Go to GitHub repo") [![stars - 3D Portfolio](https://img.shields.io/github/stars/Deri-Kurniawan/3d-portfolio?style=social)](https://github.com/Deri-Kurniawan/3d-portfolio)
[![forks - 3D Portfolio](https://img.shields.io/github/forks/Deri-Kurniawan/3d-portfolio?style=social)](https://github.com/Deri-Kurniawan/3d-portfolio) [![License](https://img.shields.io/badge/License-MIT-blue)](#license) [![issues - 3D Portfolio](https://img.shields.io/github/issues/Deri-Kurniawan/3d-portfolio)](https://github.com/Deri-Kurniawan/3d-portfolio/issues)

This portfolio is based on my designs in [Dribble - Deri Kurniawan](https://dribbble.com/shots/21642242-3D-Theme-Portfolio-Website?utm_source=Clipboard_Shot&utm_campaign=deri-kurniawan&utm_content=3D%20Theme%20Portfolio%20Website&utm_medium=Social_Share&utm_source=Clipboard_Shot&utm_campaign=deri-kurniawan&utm_content=3D%20Theme%20Portfolio%20Website&utm_medium=Social_Share). You can also find the figma design there.

This App Deployed at Vercel - [https://3d-portfolio.deri.my.id](https://3d-portfolio.deri.my.id)

## License

Released under [MIT](/LICENSE) by [@Deri-Kurniawan](https://github.com/Deri-Kurniawan).
